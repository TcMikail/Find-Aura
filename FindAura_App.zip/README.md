# FindAura

A React app to report and track missing children with multimedia alerts.

## Setup

1. Run `npm install`
2. Run `npm start`
3. Open `http://localhost:3000`

## Deployment

You can deploy using [Vercel](https://vercel.com/) or [Netlify](https://netlify.com/).
