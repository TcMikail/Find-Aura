# Find-Aura
Futuristic and emotionally impactful mobile app to locate missing children using AI, real-time maps, and secure chat.
